The cover is pre-oriented on the plate, but you might need to tweak it depending on your setup. I did mine on my K1.

PLA printed at 220 nozzle and 60 bed. I did 25% infill with 4 wall loops, but while testing, I found infill could be dropped as low as 13% depending on custom supports.

Tree supports are needed. Slice the print and see where additional supports are necessary and paint them in.

I gave up on lining up the bottom hole, so you can either drill it out, or you can just tighten the bolt for the upper hole. I did this and it's been fine.

~~~

There are other 3D printed ones available online, but I never thought they looked good enough to buy, and nobody gives out their files for free lol. The metal ones look great, but in my eyes, they're pricey. Remix this, drill it, do whatever you want to make it perfect for you, just don't sell it. This is by no means a perfect project, but I made it because I couldn't justify the cost for something that's only ever seen during oil changes and Instagram. 














